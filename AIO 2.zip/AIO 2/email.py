import csv
import re


def is_valid_email(email):
    # Email formatini tekshirish
    email_pattern = r'^\S+@\S+\.\S+$'
    return re.match(email_pattern, email)


def is_email_exists(email):
    with open('AIO_S/emails.csv', mode='r', newline='') as file:
        reader = csv.reader(file)
        for row in reader:
            if email in row:
                return True
    return False


def save_email_to_csv(email):
    with open('AIO_S/emails.csv', mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([email])


def main():
    while True:
        email = input("Iltimos, email manzilni kiriting (yoki chiqish uchun 'exit' yozing): ").strip()

        if email.lower() == 'exit':
            break

        if is_valid_email(email):
            if not is_email_exists(email):
                save_email_to_csv(email)
                print("Email manzil saqlandi.")
            else:
                print("Bu email manzili allaqachon saqlangan.")
        else:
            print("Noto'g'ri email formati. Qayta kiriting.")


if __name__ == "__main__":
    main()
