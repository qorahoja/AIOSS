from django.apps import AppConfig


class AioConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'aio'
